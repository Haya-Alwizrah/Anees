# Arabic Handwriting Evaluator

Recognises a handwritten Arabic letter and grades how well a child wrote it.
Everything — preprocessing, data loading, the CNN, training, evaluation and the
scoring engine — lives in a single class in
[`arabic_handwriting_evaluator.py`](arabic_handwriting_evaluator.py).

Trained on the **Hijja** dataset (47,434 characters written by 591 Saudi school
children aged 7–12), 29 classes: the 28 Arabic letters plus hamza.

**Test accuracy: 92.93%** on 9,501 held-out characters.

---

## Requirements

```bash
pip install tensorflow opencv-python numpy pandas matplotlib scikit-learn
```

TensorFlow needs **Python 3.9–3.13** — there is no wheel for 3.14.

## Data

Put the four head-less CSV files beside the folder (or pass `--data-dir`):

```
train_X.csv  (37933 x 1024)   train_Y.csv  (37933 labels, 1..29)
test_X.csv   (9501  x 1024)   test_Y.csv   (9501  labels, 1..29)
```

Each row is a 32×32 greyscale image, white ink on black. A pre-packed
`hijja2.npz` (keys `Xtr/ytr/Xte/yte`) is used automatically when present and
loads far faster than parsing the CSVs.

## Command line

```bash
python arabic_handwriting_evaluator.py                       # train 30 epochs, evaluate
python arabic_handwriting_evaluator.py --epochs 5            # quick run
python arabic_handwriting_evaluator.py --no-train            # load the saved model
python arabic_handwriting_evaluator.py --no-train --image photo.jpg --target 2
python arabic_handwriting_evaluator.py --show-steps photo.jpg
```

`--target` is 1..29 — the letter the child was **asked** to write. When given,
the score is the probability of *that* class, not of the top prediction.
Add `--adaptive` for badly lit phone photos.

## As a library

```python
from arabic_handwriting_evaluator import ArabicHandwritingEvaluator

ev = ArabicHandwritingEvaluator(data_dir="/path/to/csvs")

X_train, y_train, X_test, y_test = ev.load_dataset(ev.data_dir)
X_tr, X_val, y_tr, y_val = ev.stratified_split(X_train, y_train)

ev.model = ev.build_model()
ev.train_model(ev.model, X_tr, y_tr, X_val, y_val, epochs=30,
               batch_size=128, model_path=ev.model_path)
ev.evaluate_on_test(ev.model, X_test, y_test)

result = ev.evaluate_handwriting(ev.model, "photo.jpg", target_letter_index=2)
print(result["grade"], result["score"])
```

## What the class contains

| Area | Methods |
|---|---|
| Preprocessing | `preprocess_image`, `preprocess_batch`, `show_preprocessing_steps`, `ascii_preview` |
| Data | `load_raw_data`, `load_dataset`, `stratified_split` |
| Model | `build_model`, `make_feature_extractor` |
| Training | `train_model`, `make_train_iterator`, `plot_history`, `evaluate_on_test` |
| Scoring | `evaluate_handwriting`, `print_report` |
| CLI | `run_cli` |

## The one thing worth knowing about the preprocessing

`preprocess_image` is the single entry point for **both** a photo of paper and a
dataset row, but it does not treat them the same — and that is deliberate.

A photo needs thresholding to separate pencil from paper. A Hijja CSV row does
not: it is already a clean white-on-black glyph whose strokes are 1–2 px wide and
anti-aliased. Running Otsu on it promotes every faint edge pixel to solid ink
(90 ink pixels become 222) and turns thin letters into blobs. Measured over six
identical epochs, same model, seed and split:

| Training data | Validation accuracy |
|---|---|
| Raw dataset pixels | **88.2%** |
| Forced through the photo pipeline | **43.1%** |

So `_is_clean_glyph()` sends dataset rows straight through untouched, and the
two domains are matched from the other side instead: a photographed letter is
normalised to `INK_BOX = 21` px, the mean longest side of a real Hijja glyph.

## Reading the training curve

**Ignore the first two epochs.** BatchNorm normalises with batch statistics
while training but with running averages at validation time, and those averages
have not converged early on. Epoch 1 typically reports ~4.9% validation accuracy
while training accuracy is already 33%. It corrects itself by epoch 3 (~78%).

## Outputs

| File | Contents |
|---|---|
| `arabic_handwriting_model.h5` | Best weights |
| `training_history.png` | Accuracy and loss curves |
| `confusion_matrix.png` | 29×29 confusion matrix |
| `preprocessed_32.npz` | Preprocessing cache — delete to rebuild |
| `preprocessing_steps.png` | Pipeline stages for a photo (`--show-steps`) |

## Limitations

- The similarity score is raw softmax confidence, not a calibrated similarity: a
  confidently written but malformed letter can still score highly.
- The photo branch was validated against simulated photographs (shadow
  gradients, tilt, blur, noise), not against real ink on real paper.
- Hijja mixes isolated, initial, medial and final letter forms within each
  class, which limits what a 29-way accuracy figure can mean.
